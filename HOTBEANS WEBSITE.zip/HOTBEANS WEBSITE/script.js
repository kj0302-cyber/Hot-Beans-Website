
// Find the hamburger button in the HTML using its ID
const hamburger = document.getElementById("hamburger");

// Find the list of navigation links (the menu) in the HTML
const navLinks = document.getElementById("navLinks");

// Wait for the user to click the hamburger button
hamburger.addEventListener("click", () => {

  // Switch the menu on or off when the button is clicked
  // If the menu is hidden, this will show it
  // If the menu is showing, this will hide it
  navLinks.classList.toggle("active");

});








// ================= APPLICATION FORM VALIDATION =================

// Get the form element
const form = document.getElementById("applicationForm");

// Listen for form submission
form.addEventListener("submit", (event) => {

    // Prevents the page from refreshing
    event.preventDefault();

    // Get input values
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const qualification = document.getElementById("qualification").value;

    // Simple validation check
    if (name === "" || email === "" || qualification === "") {
        alert("Please fill in all fields before submitting.");
    } else {
        alert("Application submitted successfully!");
        form.reset();
    }
});











// ================= CONTACT FORM VALIDATION =================

const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const name = document.getElementById("contactName").value;
    const email = document.getElementById("contactEmail").value;
    const message = document.getElementById("message").value;

    if (name === "" || email === "" || message === "") {
        alert("Please fill in all fields before sending your message.");
    } else {
        alert("Thank you for contacting us!");
        contactForm.reset();
    }
});





